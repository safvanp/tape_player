import 'package:flutter/material.dart';

class TapeButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool isTapped;

  const TapeButton({
    required this.icon,
    required this.onTap,
    this.isTapped = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 150),
        curve: Curves.easeInOut,
        width: isTapped ? 44 : 50,
        height: isTapped ? 44 : 50,
        decoration: BoxDecoration(
          color: Color.fromRGBO(0, 0, 0, 0.9),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black87,
              blurRadius: 6,
              offset: Offset(2, 3),
            ),
            BoxShadow(
              color: Colors.grey.shade800,
              blurRadius: 2,
              offset: Offset(-2, -2),
              spreadRadius: -2,
            ),
          ],
          border: Border.all(color: Colors.grey.shade700, width: 1),
        ),
        child: Center(
          child: Icon(
            icon,
            color: Colors.white,
            size: isTapped ? 20 : 24,
          ),
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';

// class TapeButton extends StatelessWidget {
//   final IconData icon;
//   final VoidCallback onTap;
//   final bool isTapped;
//   const TapeButton(
//       {required this.icon,
//       required this.onTap,
//       this.isTapped = false,
//       super.key});

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         width: isTapped ? 45 : 50,
//         height: isTapped ? 45 : 50,
//         decoration: BoxDecoration(
//             color: Colors.black,
//             borderRadius: BorderRadius.all(Radius.circular(8))),
//         child: Center(
//           child: Icon(icon, color: Colors.white),
//         ),
//       ),
//     );
//   }
// }
