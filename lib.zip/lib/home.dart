import 'package:flutter/material.dart';
import 'package:tape_player/tape.dart';

class Home extends StatelessWidget {
  final VoidCallback onToggleTheme;
  final ThemeMode themeMode;

  const Home({
    super.key,
    required this.onToggleTheme,
    required this.themeMode,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tape Music Player'),
        actions: [
          IconButton(
            icon: Icon(
              themeMode == ThemeMode.dark ? Icons.dark_mode : Icons.light_mode,
            ),
            onPressed: onToggleTheme,
          ),
        ],
      ),
      body: Container(
        color: Theme.of(context).scaffoldBackgroundColor,
        child: const Center(
          child: Tape(),
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:tape_player/tape.dart';

// class Home extends StatelessWidget {
//   const Home({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       color: Colors.cyan,
//       child: Center(
//         child: Tape(),
//       ),
//     );
//   }
// }
