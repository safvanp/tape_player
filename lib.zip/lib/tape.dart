import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_media_metadata/flutter_media_metadata.dart';
import 'package:marquee/marquee.dart';
import 'package:tape_player/tape/tape_button.dart';
import 'package:tape_player/tape/tape_painter.dart';

enum TapeStatus { initial, playing, pausing, stopping, choosing }

enum RepeatMode { none, one, all }

bool showPlaylist = false;
RepeatMode repeatMode = RepeatMode.none;

class Tape extends StatefulWidget {
  const Tape({super.key});

  @override
  State<Tape> createState() => _TapeState();
}

class _TapeState extends State<Tape> with SingleTickerProviderStateMixin {
  late AnimationController animationController;
  late AudioPlayer audioPlayer;

  TapeStatus tapeStatus = TapeStatus.initial;
  List<PlatformFile> playlist = [];
  int currentIndex = 0;
  String? title;
  double currentPosition = 0.0;
  int totalDurationValue = 0;
  Duration currentDuration = Duration.zero;
  Duration totalDuration = Duration.zero;

  @override
  void initState() {
    super.initState();
    animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 10000),
    )..addListener(() => setState(() {}));

    audioPlayer = AudioPlayer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Tape Display
            SizedBox(
              width: 300,
              height: 200,
              child: CustomPaint(
                painter: TapePainter(
                  rotationValue: animationController.value,
                  title: title ?? '',
                  progress: currentPosition,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Control Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TapeButton(
                    icon: Icons.skip_previous,
                    onTap: previous,
                    isTapped: false),
                TapeButton(
                    icon: Icons.play_arrow,
                    onTap: play,
                    isTapped: tapeStatus == TapeStatus.playing),
                TapeButton(
                    icon: Icons.pause,
                    onTap: pause,
                    isTapped: tapeStatus == TapeStatus.pausing),
                TapeButton(
                    icon: Icons.stop,
                    onTap: stop,
                    isTapped: tapeStatus == TapeStatus.stopping),
                TapeButton(
                    icon: Icons.eject,
                    onTap: choose,
                    isTapped: tapeStatus == TapeStatus.choosing),
                TapeButton(icon: Icons.skip_next, onTap: next, isTapped: false),
              ],
            ),
            const SizedBox(height: 10),

            // Scrolling Title
            SizedBox(
              height: 30,
              width: 300,
              child: Marquee(
                text: title ?? "No track selected",
                style: const TextStyle(fontSize: 10),
                scrollAxis: Axis.horizontal,
                blankSpace: 40.0,
                velocity: 30.0,
                pauseAfterRound: const Duration(seconds: 1),
                startPadding: 10.0,
              ),
            ),

            // Progress & Duration
            SizedBox(
              width: 300,
              height: 80,
              child: Column(
                children: [
                  Slider(
                    min: 0.0,
                    max: totalDuration.inMilliseconds.toDouble(),
                    value: currentDuration.inMilliseconds
                        .clamp(0.0, totalDuration.inMilliseconds.toDouble())
                        .toDouble(),
                    onChanged: (value) {
                      final position = Duration(milliseconds: value.toInt());
                      audioPlayer.seek(position);
                    },
                  ),
                  Text(
                    "${_formatDuration(currentDuration)} / ${_formatDuration(totalDuration)}",
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),

            // Playlist & Repeat Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: Icon(showPlaylist ? Icons.queue_music : Icons.queue),
                  onPressed: () => setState(() => showPlaylist = !showPlaylist),
                ),
                IconButton(
                  icon: Icon(_repeatIcon()),
                  onPressed: _toggleRepeatMode,
                ),
              ],
            ),

            // Playlist Widget
            _buildPlaylist(),
          ],
        ),
      ),
    );
  }

  Widget _buildPlaylist() {
    if (!showPlaylist || playlist.isEmpty) return const SizedBox.shrink();

    return Container(
      width: 300,
      height: 180,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color.fromRGBO(0, 0, 0, 0.85),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade700),
        boxShadow: const [
          BoxShadow(
            color: Colors.black54,
            blurRadius: 10,
            offset: Offset(0, 4),
          )
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: ListView.separated(
          itemCount: playlist.length,
          itemBuilder: (context, index) {
            final file = playlist[index];
            final isSelected = index == currentIndex;

            return ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              tileColor: isSelected ? Colors.grey.shade800 : Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              title: Text(
                file.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: isSelected ? Colors.amber : Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              onTap: () {
                setState(() => currentIndex = index);
                play();
              },
            );
          },
          separatorBuilder: (_, __) => Divider(
            color: Colors.grey.shade700,
            thickness: 0.8,
            indent: 12,
            endIndent: 12,
          ),
          shrinkWrap: true,
          physics: const BouncingScrollPhysics(),
        ),
      ),
    );
  }

  IconData _repeatIcon() {
    switch (repeatMode) {
      case RepeatMode.one:
        return Icons.repeat_one;
      case RepeatMode.all:
        return Icons.repeat;
      default:
        return Icons.repeat_on_outlined;
    }
  }

  void _toggleRepeatMode() {
    setState(() {
      switch (repeatMode) {
        case RepeatMode.none:
          repeatMode = RepeatMode.one;
          break;
        case RepeatMode.one:
          repeatMode = RepeatMode.all;
          break;
        case RepeatMode.all:
          repeatMode = RepeatMode.none;
          break;
      }
    });
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return "$minutes:$seconds";
  }

  void stop() {
    animationController.stop();
    audioPlayer.stop();
    setState(() {
      tapeStatus = TapeStatus.stopping;
      currentPosition = 0.0;
    });
  }

  void pause() {
    animationController.stop();
    audioPlayer.pause();
    setState(() => tapeStatus = TapeStatus.pausing);
  }

  void play() async {
    if (playlist.isEmpty || currentIndex >= playlist.length) return;

    try {
      final path = playlist[currentIndex].path!;
      await audioPlayer.setSourceDeviceFile(path);

      // Reset UI state before playback
      setState(() {
        totalDuration = Duration.zero;
        totalDurationValue = 1;
        currentDuration = Duration.zero;
        currentPosition = 0.0;
        tapeStatus = TapeStatus.playing;
      });

      // Listen for position changes
      audioPlayer.onPositionChanged.listen((event) {
        setState(() {
          currentDuration = event;
          currentPosition = event.inMilliseconds /
              (totalDurationValue > 0 ? totalDurationValue : 1);
        });
      });

      // Listen for duration and wait before resuming
      audioPlayer.onDurationChanged.first.then((duration) async {
        if (duration.inMilliseconds > 0) {
          setState(() {
            totalDuration = duration;
            totalDurationValue = duration.inMilliseconds;
          });

          await audioPlayer.resume();
          animationController.repeat();
        }
      });

      // Get metadata
      final info = await MetadataRetriever.fromFile(File(path));
      setState(() => title = _buildTitle(info));

      // Completion logic
      audioPlayer.onPlayerComplete.listen((_) {
        switch (repeatMode) {
          case RepeatMode.one:
            play();
            break;
          case RepeatMode.all:
            currentIndex = (currentIndex + 1) % playlist.length;
            play();
            break;
          case RepeatMode.none:
            if (currentIndex < playlist.length - 1) {
              next();
            } else {
              stop();
            }
            break;
        }
      });
    } catch (ex) {
      debugPrint("Play error: $ex");
    }
  }

  String _buildTitle(Metadata info) {
    var base = 'ArtistName: ${info.albumArtistName ?? ''} '
        'albumName: ${info.albumName ?? playlist[currentIndex].name}';

    if (info.trackArtistNames != null) {
      base += ' Artists: ${info.trackArtistNames!.join(', ')}';
    }

    if (info.year != null) {
      base += ' year: ${info.year}';
    }

    return base;
  }

  void next() {
    if (playlist.isEmpty) return;
    if (currentIndex < playlist.length - 1) {
      currentIndex++;
      play();
    } else {
      stop();
    }
  }

  void previous() {
    if (playlist.isEmpty) return;
    if (currentIndex > 0) {
      currentIndex--;
      play();
    }
  }

  Future<void> choose() async {
    stop();
    setState(() => tapeStatus = TapeStatus.choosing);

    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.audio,
      withData: true,
    );

    if (result == null) return;

    setState(() {
      playlist = result.files;
      currentIndex = 0;
    });

    play();
  }

  @override
  void dispose() {
    animationController.dispose();
    audioPlayer.dispose();
    super.dispose();
  }
}

// import 'dart:io';

// import 'package:audioplayers/audioplayers.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_media_metadata/flutter_media_metadata.dart';
// import 'package:marquee/marquee.dart';
// import 'package:tape_player/tape/tape_button.dart';
// import 'package:tape_player/tape/tape_painter.dart';

// enum TapeStatus { initial, playing, pausing, stopping, choosing }

// bool showPlaylist = false;

// enum RepeatMode { none, one, all }

// RepeatMode repeatMode = RepeatMode.none;

// class Tape extends StatefulWidget {
//   const Tape({super.key});

//   @override
//   State<Tape> createState() => _TapeState();
// }

// class _TapeState extends State<Tape> with SingleTickerProviderStateMixin {
//   late AnimationController animationController;
//   late AudioPlayer audioPlayer;

//   TapeStatus tapeStatus = TapeStatus.initial;
//   List<PlatformFile> playlist = [];
//   int currentIndex = 0;
//   String? title;
//   double currentPosition = 0.0;
//   int totalDurationValue = 0;
//   Duration currentDuration = Duration.zero;
//   Duration totalDuration = Duration.zero;

//   @override
//   void initState() {
//     super.initState();

//     animationController = AnimationController(
//         vsync: this, duration: Duration(milliseconds: 10000));

//     Tween<double> tween = Tween<double>(begin: 0.0, end: 1.0);

//     tween.animate(animationController);
//     audioPlayer = AudioPlayer();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             SizedBox(
//               width: 300,
//               height: 200,
//               child: AnimatedBuilder(
//                 animation: animationController,
//                 builder: (context, child) {
//                   return CustomPaint(
//                     painter: TapePainter(
//                         rotationValue: animationController.value,
//                         title: title ?? '',
//                         progress: currentPosition),
//                   );
//                 },
//               ),
//             ),
//             const SizedBox(height: 20),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               spacing: 2,
//               children: [
//                 TapeButton(
//                     icon: Icons.skip_previous,
//                     onTap: previous,
//                     isTapped: false),
//                 TapeButton(
//                     icon: Icons.play_arrow,
//                     onTap: play,
//                     isTapped: tapeStatus == TapeStatus.playing),
//                 TapeButton(
//                     icon: Icons.pause,
//                     onTap: pause,
//                     isTapped: tapeStatus == TapeStatus.pausing),
//                 TapeButton(
//                     icon: Icons.stop,
//                     onTap: stop,
//                     isTapped: tapeStatus == TapeStatus.stopping),
//                 TapeButton(
//                     icon: Icons.eject,
//                     onTap: choose,
//                     isTapped: tapeStatus == TapeStatus.choosing),
//                 TapeButton(icon: Icons.skip_next, onTap: next, isTapped: false),
//               ],
//             ),
//             const SizedBox(height: 10),
//             SizedBox(
//               height: 30,
//               width: 300,
//               child: Marquee(
//                 text: title ?? "No track selected",
//                 style: const TextStyle(fontSize: 10),
//                 scrollAxis: Axis.horizontal,
//                 blankSpace: 40.0,
//                 velocity: 30.0,
//                 pauseAfterRound: Duration(seconds: 1),
//                 startPadding: 10.0,
//               ),
//             ),
//             SizedBox(
//               width: 300,
//               height: 80,
//               child: Column(
//                 children: [
//                   Slider(
//                     min: 0.0,
//                     max: totalDuration.inMilliseconds.toDouble(),
//                     value: currentDuration.inMilliseconds
//                         .toDouble()
//                         .clamp(0.0, totalDuration.inMilliseconds.toDouble()),
//                     onChanged: (value) {
//                       final position = Duration(milliseconds: value.toInt());
//                       audioPlayer.seek(position);
//                     },
//                   ),
//                   Text(
//                     "${_formatDuration(currentDuration)} / ${_formatDuration(totalDuration)}",
//                     style: TextStyle(fontSize: 12),
//                   ),
//                 ],
//               ),
//             ),
//             Row(mainAxisAlignment: MainAxisAlignment.center, children: [
//               IconButton(
//                 icon: Icon(showPlaylist ? Icons.queue_music : Icons.queue),
//                 onPressed: () => setState(() => showPlaylist = !showPlaylist),
//               ),
//               IconButton(
//                 icon: Icon(() {
//                   switch (repeatMode) {
//                     case RepeatMode.one:
//                       return Icons.repeat_one;
//                     case RepeatMode.all:
//                       return Icons.repeat;
//                     default:
//                       return Icons.repeat_on_outlined;
//                   }
//                 }()),
//                 onPressed: () {
//                   setState(() {
//                     switch (repeatMode) {
//                       case RepeatMode.none:
//                         repeatMode = RepeatMode.one;
//                         break;
//                       case RepeatMode.one:
//                         repeatMode = RepeatMode.all;
//                         break;
//                       case RepeatMode.all:
//                         repeatMode = RepeatMode.none;
//                         break;
//                     }
//                   });
//                 },
//               ),
//             ]),
//             playList(),
//           ],
//         ),
//       ),
//     );
//   }

//   playList() {
//     if (showPlaylist && playlist.isNotEmpty) {
//       return Container(
//         width: 300,
//         height: 180,
//         padding: EdgeInsets.all(8),
//         decoration: BoxDecoration(
//           color: Color.fromRGBO(0, 0, 0, 0.85),
//           borderRadius: BorderRadius.circular(16),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black54,
//               blurRadius: 10,
//               offset: Offset(0, 4),
//             )
//           ],
//           border: Border.all(color: Colors.grey.shade700, width: 1),
//         ),
//         child: ClipRRect(
//           borderRadius: BorderRadius.circular(12),
//           child: ListView.separated(
//             itemCount: playlist.length,
//             itemBuilder: (context, index) {
//               final file = playlist[index];
//               final isSelected = index == currentIndex;
//               return ListTile(
//                 contentPadding: EdgeInsets.symmetric(horizontal: 12),
//                 tileColor:
//                     isSelected ? Colors.grey.shade800 : Colors.transparent,
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 title: Text(
//                   file.name,
//                   maxLines: 1,
//                   overflow: TextOverflow.ellipsis,
//                   style: TextStyle(
//                     color: isSelected ? Colors.amber : Colors.white,
//                     fontSize: 12,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//                 onTap: () {
//                   setState(() {
//                     currentIndex = index;
//                   });
//                   play();
//                 },
//               );
//             },
//             separatorBuilder: (context, index) => Divider(
//               color: Colors.grey.shade700,
//               thickness: 0.8,
//               indent: 12,
//               endIndent: 12,
//             ),
//             shrinkWrap: true,
//             physics: BouncingScrollPhysics(),
//           ),
//         ),
//       );
//     } else {
//       return Container();
//     }
//   }

//   String _formatDuration(Duration duration) {
//     String twoDigits(int n) => n.toString().padLeft(2, '0');
//     final minutes = twoDigits(duration.inMinutes.remainder(60));
//     final seconds = twoDigits(duration.inSeconds.remainder(60));
//     return "$minutes:$seconds";
//   }

//   void stop() {
//     animationController.stop();
//     audioPlayer.stop();
//     setState(() {
//       tapeStatus = TapeStatus.stopping;
//       currentPosition = 0.0;
//     });
//   }

//   void pause() {
//     animationController.stop();
//     audioPlayer.pause();
//     setState(() {
//       tapeStatus = TapeStatus.pausing;
//     });
//   }

//   void play() async {
//     if (playlist.isEmpty || currentIndex >= playlist.length) return;

//     try {
//       final path = playlist[currentIndex].path!;
//       // await audioPlayer.setSourceUrl(path);
//       await audioPlayer.setSourceDeviceFile(path);
//       await audioPlayer.resume();

//       final info = await MetadataRetriever.fromFile(File(path));
//       totalDurationValue = info.trackDuration ?? 1;

//       audioPlayer.onPositionChanged.listen((event) {
//         setState(() {
//           currentDuration = event;
//           currentPosition = event.inMilliseconds / totalDurationValue;
//         });
//       });

//       audioPlayer.onDurationChanged.listen((duration) {
//         setState(() {
//           totalDuration = duration;
//         });
//       });
//       audioPlayer.onPlayerComplete.listen((event) {
//         switch (repeatMode) {
//           case RepeatMode.one:
//             play(); // repeat same track
//             break;
//           case RepeatMode.all:
//             if (currentIndex < playlist.length - 1) {
//               currentIndex++;
//             } else {
//               currentIndex = 0; // loop to the start
//             }
//             play();
//             // next(); // move to next, loop if at end
//             break;
//           case RepeatMode.none:
//             if (currentIndex < playlist.length - 1) {
//               next();
//             } else {
//               stop();
//             }
//             break;
//         }
//       });

//       setState(() {
//         tapeStatus = TapeStatus.playing;
//         animationController.repeat();
//         title =
//             'ArtistName: ${info.albumArtistName ?? ''} albumName: ${info.albumName ?? playlist[currentIndex].name}';
//         title = info.trackArtistNames != null
//             ? '${title!} Artists: ${info.trackArtistNames.toString()}'
//             : title;
//         title = info.year != null ? '${title!} year: ${info.year}' : title;
//         debugPrint('$info');
//       });
//     } catch (ex) {
//       ex.toString();
//     }
//   }

//   void next() {
//     if (playlist.isEmpty) return;
//     if (currentIndex < playlist.length - 1) {
//       currentIndex++;
//       play();
//     } else {
//       stop();
//     }
//   }

//   void previous() {
//     if (playlist.isEmpty) return;
//     if (currentIndex > 0) {
//       currentIndex--;
//       play();
//     }
//   }

//   Future<void> choose() async {
//     stop();
//     setState(() => tapeStatus = TapeStatus.choosing);

//     FilePickerResult? result = await FilePicker.platform
//         .pickFiles(allowMultiple: true, type: FileType.audio, withData: true);

//     if (result == null) return;

//     playlist = result.files;
//     currentIndex = 0;

//     play();
//   }

//   @override
//   void dispose() {
//     animationController.dispose();
//     audioPlayer.dispose();
//     super.dispose();
//   }
// }
